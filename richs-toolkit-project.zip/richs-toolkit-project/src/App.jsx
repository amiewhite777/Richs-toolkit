import RichsToolkit from './RichsToolkit'

function App() {
  return <RichsToolkit />
}

export default App
